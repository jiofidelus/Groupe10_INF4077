import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conseil',
  templateUrl: './conseil.page.html',
  styleUrls: ['./conseil.page.scss'],
})
export class ConseilPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
