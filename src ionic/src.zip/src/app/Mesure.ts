export class Mesure {
    idmesure?: number;
    soif?: string;
    troubedigest?: string;
    vomissement?: string;
    fatigue?: string;
    diarrhee?: string;
    personne?: any;
}